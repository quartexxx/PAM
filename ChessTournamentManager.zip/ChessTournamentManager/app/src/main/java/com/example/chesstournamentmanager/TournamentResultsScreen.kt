package com.example.chesstournamentmanager.ui

import androidx.compose.foundation.layout.* // Import układów i przestrzeni
import androidx.compose.material3.Button // Import przycisków
import androidx.compose.material3.MaterialTheme // Import motywu Material Design
import androidx.compose.material3.Text // Import komponentu tekstowego
import androidx.compose.runtime.Composable // Import funkcji Composable
import androidx.compose.ui.Alignment // Import wyrównania elementów
import androidx.compose.ui.Modifier // Import modyfikatora dla układu i komponentów
import androidx.compose.ui.unit.dp // Import jednostki dp dla odległości i rozmiarów
import com.example.chesstournamentmanager.data.Player // Import klasy Player

/**
 * Ekran wyświetlania wyników końcowych turnieju.
 *
 * @param results Mapa zawierająca zawodników i ich zdobyte punkty.
 * @param system Wybrany system turnieju (np. "Pucharowy", "Szwajcarski").
 * @param onRestartTournament Funkcja wywoływana po kliknięciu "Rozpocznij nowy turniej".
 */
@Composable
fun TournamentResultsScreen(
    results: Map<Player, Float>, // Wyniki końcowe graczy
    system: String, // Wybrany system turniejowy
    onRestartTournament: () -> Unit // Funkcja obsługująca rozpoczęcie nowego turnieju
) {
    // Główny kontener ekranu w formie kolumny
    Column(
        modifier = Modifier
            .fillMaxSize() // Wypełnij dostępną przestrzeń
            .padding(24.dp), // Dodaj odstęp wewnętrzny
        verticalArrangement = Arrangement.spacedBy(16.dp), // Odstępy między elementami
        horizontalAlignment = Alignment.CenterHorizontally // Wyśrodkowanie w poziomie
    ) {
        // Nagłówek
        Text(
            text = "Wyniki końcowe", // Tekst nagłówka
            style = MaterialTheme.typography.headlineSmall // Styl nagłówka zgodny z Material Design
        )

        // Wyświetlenie wyników zależnie od systemu
        if (system == "Pucharowy") {
            // Logika dla systemu pucharowego: wyświetlenie zwycięzcy
            if (results.isNotEmpty()) {
                // Znalezienie zawodnika z najwyższym wynikiem
                val winner = results.entries.maxByOrNull { it.value }?.key
                winner?.let {
                    Text(
                        text = "Zwycięzca turnieju: ${it.name}", // Wyświetlenie zwycięzcy
                        style = MaterialTheme.typography.titleMedium // Styl tekstu
                    )
                }
            } else {
                // Obsługa przypadku, gdy brak wyników
                Text(
                    text = "Nie udało się określić zwycięzcy.", // Komunikat o braku zwycięzcy
                    style = MaterialTheme.typography.titleMedium // Styl tekstu
                )
            }
        } else {
            // Logika dla innych systemów: wyświetlenie tabeli wyników
            results.entries.sortedByDescending { it.value }.forEach { (player, score) ->
                Text(text = "${player.name}: ${score} pkt") // Wyświetlenie punktów gracza
            }
        }

        Spacer(modifier = Modifier.height(24.dp)) // Dodanie odstępu

        // Przycisk do rozpoczęcia nowego turnieju
        Button(
            onClick = onRestartTournament, // Wywołanie funkcji restartu turnieju
            modifier = Modifier.fillMaxWidth() // Wypełnienie szerokości przycisku
        ) {
            Text("Rozpocznij nowy turniej") // Tekst przycisku
        }
    }
}
