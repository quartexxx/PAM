package com.example.chesstournamentmanager.ui

import androidx.compose.foundation.layout.* // Import układu do tworzenia kolumn, odstępów itp.
import androidx.compose.material3.Button // Import przycisku
import androidx.compose.material3.MaterialTheme // Import stylu Material Design
import androidx.compose.material3.Text // Import komponentu tekstowego
import androidx.compose.runtime.Composable // Import funkcji oznaczonych jako @Composable
import androidx.compose.ui.Alignment // Import wyrównywania elementów w układzie
import androidx.compose.ui.Modifier // Import modyfikatorów dla komponentów
import androidx.compose.ui.unit.dp // Import jednostek miary (np. dp)
import com.example.chesstournamentmanager.data.Player // Import klasy Player

// Funkcja @Composable służąca do wyświetlania wyników rund
@Composable
fun RoundResultsScreen(
    roundResults: List<Pair<Pair<Player, Player>, Pair<Float, Float>>>, // Lista wyników rund: pary zawodników i ich punktacja
    onBack: () -> Unit // Funkcja wywoływana po naciśnięciu przycisku "Powrót"
) {
    // Układ główny kolumny, obejmujący wszystkie elementy na ekranie
    Column(
        modifier = Modifier
            .fillMaxSize() // Ustawienie, aby kolumna wypełniała cały ekran
            .padding(16.dp), // Dodanie marginesu 16 dp na wszystkich krawędziach
        verticalArrangement = Arrangement.spacedBy(8.dp), // Odstępy 8 dp między elementami
        horizontalAlignment = Alignment.CenterHorizontally // Wyśrodkowanie elementów w poziomie
    ) {
        // Nagłówek ekranu
        Text(
            text = "Wyniki rund", // Treść nagłówka
            style = MaterialTheme.typography.headlineSmall // Styl tekstu dla nagłówka
        )

        // Iterowanie przez wyniki rund i wyświetlanie ich w podziale na rundy
        roundResults.chunked(2).forEachIndexed { index, results ->
            // Dzielimy wyniki na grupy po 2, aby odwzorować poszczególne rundy
            Text(
                text = "Runda ${index + 1}:", // Wyświetlanie numeru rundy
                style = MaterialTheme.typography.titleMedium // Styl tekstu dla tytułu
            )
            // Wyświetlanie wyników dla każdej pary zawodników w tej rundzie
            results.forEach { (pair, scores) ->
                Text(
                    text = "${pair.first.name} (${scores.first}) vs ${pair.second.name} (${scores.second})"
                    // Wyświetla imiona graczy oraz ich punkty w formacie "Gracz1 (pkt) vs Gracz2 (pkt)"
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp)) // Dodanie odstępu przed przyciskiem

        // Przycisk powrotu
        Button(
            onClick = onBack, // Wywołanie funkcji przekazanej jako parametr onBack
            modifier = Modifier.fillMaxWidth() // Przycisk zajmuje całą szerokość dostępnej przestrzeni
        ) {
            Text("Powrót") // Treść przycisku
        }
    }
}
