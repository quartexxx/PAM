package com.example.chesstournamentmanager

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.chesstournamentmanager.data.Player
import kotlin.math.ceil
import kotlin.math.log2

@Composable
fun ConfigureTournamentScreen(
    selectedPlayers: List<Player>, // Lista zawodników wybranych do turnieju
    onStartTournament: (String, Int, String) -> Unit, // Funkcja wywoływana po rozpoczęciu turnieju, z parametrami: system, liczba rund, metoda remisów
    onBackToSelectPlayers: () -> Unit // Funkcja wywoływana po powrocie do ekranu wyboru zawodników
) {
    // Przechowywanie wybranego systemu turnieju
    var selectedSystem by remember { mutableStateOf("Szwajcarski") }

    // Przechowywanie wybranego systemu remisów
    var selectedTieBreakMethod by remember { mutableStateOf("Progres") }

    // Zarządzanie rozwijanym menu dla systemu turnieju
    var isSystemDropdownExpanded by remember { mutableStateOf(false) }

    // Zarządzanie rozwijanym menu dla systemu remisów
    var isTieBreakDropdownExpanded by remember { mutableStateOf(false) }

    // Automatyczne obliczanie liczby rund na podstawie wybranego systemu i liczby zawodników
    val calculatedRounds = if (selectedSystem == "Szwajcarski" || selectedSystem == "Pucharowy") {
        ceil(log2(selectedPlayers.size.toDouble())).toInt() // Liczba rund to log2(liczba zawodników), zaokrąglona w górę
    } else {
        1 // W innych przypadkach domyślnie 1 runda
    }

    // Główny układ ekranu
    Column(
        modifier = Modifier
            .fillMaxSize() // Ekran zajmuje całą dostępną przestrzeń
            .padding(24.dp), // Dodanie odstępów od krawędzi ekranu
        verticalArrangement = Arrangement.spacedBy(16.dp), // Równy odstęp między elementami
        horizontalAlignment = Alignment.CenterHorizontally // Wyśrodkowanie elementów w poziomie
    ) {
        // Nagłówek ekranu
        Text(
            text = "Konfiguracja turnieju",
            style = MaterialTheme.typography.headlineSmall
        )
        Text("Wybrano zawodników: ${selectedPlayers.size}") // Wyświetlenie liczby zawodników

        // Sekcja wyboru systemu turnieju
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(text = "System turnieju:")
            Button(
                onClick = { isSystemDropdownExpanded = true }, // Rozwijane menu systemu turnieju
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(selectedSystem) // Wyświetlenie aktualnie wybranego systemu
            }
            DropdownMenu(
                expanded = isSystemDropdownExpanded, // Czy menu jest rozwinięte
                onDismissRequest = { isSystemDropdownExpanded = false } // Zamknięcie menu
            ) {
                DropdownMenuItem(
                    text = { Text("Szwajcarski") }, // Opcja systemu szwajcarskiego
                    onClick = {
                        selectedSystem = "Szwajcarski" // Ustawienie wybranego systemu
                        isSystemDropdownExpanded = false // Zamknięcie menu
                    }
                )
                DropdownMenuItem(
                    text = { Text("Pucharowy") }, // Opcja systemu pucharowego
                    onClick = {
                        selectedSystem = "Pucharowy" // Ustawienie wybranego systemu
                        isSystemDropdownExpanded = false // Zamknięcie menu
                    }
                )
            }
        }

        // Sekcja wyboru systemu remisów
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(text = "System remisów:")
            Button(
                onClick = { isTieBreakDropdownExpanded = true }, // Rozwijane menu systemu remisów
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(selectedTieBreakMethod) // Wyświetlenie aktualnie wybranego systemu remisów
            }
            DropdownMenu(
                expanded = isTieBreakDropdownExpanded, // Czy menu jest rozwinięte
                onDismissRequest = { isTieBreakDropdownExpanded = false } // Zamknięcie menu
            ) {
                DropdownMenuItem(
                    text = { Text("Progres") }, // Opcja systemu Progres
                    onClick = {
                        selectedTieBreakMethod = "Progres" // Ustawienie wybranego systemu remisów
                        isTieBreakDropdownExpanded = false // Zamknięcie menu
                    }
                )
                DropdownMenuItem(
                    text = { Text("Sumaryczny") }, // Opcja systemu Sumarycznego
                    onClick = {
                        selectedTieBreakMethod = "Sumaryczny" // Ustawienie wybranego systemu remisów
                        isTieBreakDropdownExpanded = false // Zamknięcie menu
                    }
                )
            }
        }

        // Przycisk rozpoczęcia turnieju
        Button(
            onClick = { onStartTournament(selectedSystem, calculatedRounds, selectedTieBreakMethod) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Rozpocznij turniej")
        }

        // Przycisk powrotu
        Button(
            onClick = onBackToSelectPlayers,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Powrót do wyboru zawodników")
        }
    }
}
