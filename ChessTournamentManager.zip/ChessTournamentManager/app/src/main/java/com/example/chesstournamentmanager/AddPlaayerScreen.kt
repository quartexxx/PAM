package com.example.chesstournamentmanager

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.chesstournamentmanager.data.Player
import androidx.compose.ui.Alignment

@Composable
fun AddPlayerScreen(
    players: List<Player>, // Lista zawodników aktualnie dodanych do aplikacji
    onAddPlayer: (String, Int?) -> Unit, // Funkcja do obsługi dodawania nowego zawodnika
    onClearPlayers: () -> Unit, // Funkcja do usuwania wszystkich zawodników
    onNavigateToSelectPlayers: () -> Unit // Funkcja do przejścia na ekran wyboru zawodników
) {
    // Przechowywanie wartości wpisanego imienia i nazwiska zawodnika
    var playerName = remember { mutableStateOf("") }

    // Przechowywanie wartości wpisanego rankingu zawodnika
    var playerRating = remember { mutableStateOf("") }

    // Główny układ ekranu oparty na kolumnie
    Column(
        modifier = Modifier
            .fillMaxSize() // Zajmuje całą dostępną przestrzeń
            .padding(24.dp), // Marginesy z każdej strony
        verticalArrangement = Arrangement.spacedBy(16.dp), // Równe odstępy między elementami w kolumnie
        horizontalAlignment = Alignment.CenterHorizontally // Wyśrodkowanie elementów na osi poziomej
    ) {
        // Nagłówek ekranu
        Text(
            text = "Dodaj zawodnika",
            style = MaterialTheme.typography.headlineSmall // Styl nagłówka
        )

        // Pole tekstowe do wpisywania imienia i nazwiska zawodnika
        TextField(
            value = playerName.value, // Aktualna wartość pola tekstowego
            onValueChange = { playerName.value = it }, // Funkcja aktualizująca wartość
            label = { Text("Imię i nazwisko zawodnika") }, // Etykieta pola
            modifier = Modifier.fillMaxWidth() // Pole zajmuje pełną szerokość kontenera
        )



        // Przycisk dodania zawodnika
        Button(
            onClick = {
                val name = playerName.value.trim() // Usuwa białe znaki na początku i końcu tekstu
                val rating = playerRating.value.toIntOrNull() // Przekształca tekst na liczbę całkowitą lub zwraca `null`

                if (name.isNotEmpty()) { // Sprawdza, czy imię nie jest puste
                    onAddPlayer(name, rating) // Wywołuje funkcję dodającą zawodnika
                    playerName.value = "" // Resetuje pole imienia
                    playerRating.value = "" // Resetuje pole rankingu
                }
            },
            modifier = Modifier.fillMaxWidth() // Przycisk zajmuje pełną szerokość
        ) {
            Text("Dodaj zawodnika")
        }

        // Przycisk czyszczenia listy zawodników
        Button(
            onClick = onClearPlayers, // Funkcja wywoływana po kliknięciu
            modifier = Modifier.fillMaxWidth() // Przycisk zajmuje pełną szerokość
        ) {
            Text("Wyczyść listę zawodników")
        }

        // Przycisk przejścia do ekranu wyboru zawodników
        Button(
            onClick = onNavigateToSelectPlayers, // Funkcja wywoływana po kliknięciu
            modifier = Modifier.fillMaxWidth() // Przycisk zajmuje pełną szerokość
        ) {
            Text("Przejdź do wyboru zawodników")
        }
    }
}
