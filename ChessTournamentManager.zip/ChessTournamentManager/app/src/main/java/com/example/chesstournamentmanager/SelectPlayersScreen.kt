package com.example.chesstournamentmanager

import androidx.compose.foundation.layout.* // Import układów i przestrzeni
import androidx.compose.material3.Button // Import przycisków
import androidx.compose.material3.Checkbox // Import komponentu checkbox
import androidx.compose.material3.MaterialTheme // Import motywu Material Design
import androidx.compose.material3.Text // Import komponentu tekstowego
import androidx.compose.runtime.Composable // Import funkcji Composable
import androidx.compose.runtime.mutableStateOf // Import zarządzania stanem
import androidx.compose.runtime.remember // Import pamiętania stanu
import androidx.compose.ui.Alignment // Import wyrównania elementów
import androidx.compose.ui.Modifier // Import modyfikatora dla układu i komponentów
import androidx.compose.ui.unit.dp // Import jednostki dp dla odległości i rozmiarów
import androidx.navigation.NavHostController // Import kontrolera nawigacji
import com.example.chesstournamentmanager.data.Player // Import klasy Player

/**
 * Ekran wyboru zawodników do turnieju.
 *
 * @param players Lista zawodników dostępnych do wyboru.
 * @param onPlayerSelected Funkcja wywoływana przy zaznaczeniu lub odznaczeniu zawodnika.
 * @param onProceed Funkcja wywoływana po kliknięciu "Przejdź do ustawień turnieju".
 * @param onBackToAddPlayers Funkcja wywoływana po kliknięciu "Powrót do dodawania zawodników".
 * @param navController Kontroler nawigacji używany do przejścia między ekranami.
 */
@Composable
fun SelectPlayersScreen(
    players: List<Player>, // Lista wszystkich zawodników do wyświetlenia
    onPlayerSelected: (Player, Boolean) -> Unit, // Funkcja obsługująca wybór zawodnika
    onProceed: () -> Unit, // Funkcja obsługująca przejście do kolejnego ekranu
    onBackToAddPlayers: () -> Unit, // Funkcja obsługująca powrót do ekranu dodawania zawodników
    navController: NavHostController // Kontroler nawigacji do sterowania przejściami między ekranami
) {
    // Główny kontener ekranu w postaci kolumny
    Column(
        modifier = Modifier
            .fillMaxSize() // Wypełnij dostępną przestrzeń
            .padding(24.dp), // Dodaj odstęp wewnętrzny
        verticalArrangement = Arrangement.spacedBy(16.dp), // Odstępy między elementami
        horizontalAlignment = Alignment.CenterHorizontally // Wyśrodkowanie w poziomie
    ) {
        // Nagłówek ekranu
        Text(
            text = "Wybierz zawodników do turnieju", // Tekst nagłówka
            style = MaterialTheme.typography.headlineSmall // Styl nagłówka zgodny z Material Design
        )

        // Lista zawodników z opcją zaznaczania
        Column(
            modifier = Modifier.fillMaxWidth(), // Wypełnij szerokość
            verticalArrangement = Arrangement.spacedBy(8.dp) // Odstępy między wierszami
        ) {
            players.forEach { player -> // Iteracja przez listę zawodników
                val isSelected = remember { mutableStateOf(false) } // Zapamiętanie stanu zaznaczenia
                Row(
                    modifier = Modifier
                        .fillMaxWidth() // Wypełnij szerokość wiersza
                        .padding(vertical = 4.dp), // Dodaj odstępy pionowe
                    horizontalArrangement = Arrangement.SpaceBetween // Rozmieść elementy równomiernie
                ) {
                    Text(text = player.name) // Wyświetl imię i nazwisko zawodnika
                    Checkbox(
                        checked = isSelected.value, // Stan zaznaczenia
                        onCheckedChange = { checked -> // Obsługa zmiany zaznaczenia
                            isSelected.value = checked // Aktualizacja stanu zaznaczenia
                            onPlayerSelected(player, checked) // Wywołanie funkcji obsługującej wybór
                        }
                    )
                }
            }
        }

        // Przycisk przejścia do ustawień turnieju
        Button(
            onClick = { navController.navigate("configure_tournament") }, // Nawigacja do ekranu ustawień turnieju
            modifier = Modifier.fillMaxWidth() // Wypełnij szerokość
        ) {
            Text("Przejdź do ustawień turnieju") // Tekst przycisku
        }

        // Przycisk powrotu do ekranu dodawania zawodników
        Button(
            onClick = onBackToAddPlayers, // Wywołanie funkcji powrotu
            modifier = Modifier.fillMaxWidth() // Wypełnij szerokość
        ) {
            Text("Powrót do dodawania zawodników") // Tekst przycisku
        }
    }
}
