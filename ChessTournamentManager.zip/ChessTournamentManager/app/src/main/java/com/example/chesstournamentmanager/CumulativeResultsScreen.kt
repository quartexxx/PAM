package com.example.chesstournamentmanager.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.chesstournamentmanager.data.Player

@Composable
fun CumulativeResultsScreen(
    cumulativeResults: Map<Player, Float>, // Mapa z zawodnikami i ich aktualnymi wynikami zbiorczymi
    onBack: () -> Unit // Funkcja wywoływana po kliknięciu przycisku "Powrót"
) {
    // Główny układ kolumnowy ekranu
    Column(
        modifier = Modifier
            .fillMaxSize() // Wypełnienie całej dostępnej przestrzeni
            .padding(16.dp), // Marginesy wewnętrzne na całym ekranie
        verticalArrangement = Arrangement.spacedBy(8.dp), // Odstępy pionowe między elementami
        horizontalAlignment = Alignment.CenterHorizontally // Wyśrodkowanie elementów w poziomie
    ) {
        // Nagłówek ekranu
        Text(
            text = "Bieżące wyniki zbiorcze", // Tytuł ekranu
            style = MaterialTheme.typography.headlineSmall // Styl tytułu
        )

        // Wyświetlanie wyników zawodników w porządku malejącym według punktów
        cumulativeResults.entries.sortedByDescending { it.value }.forEach { (player, score) ->
            // Dla każdego zawodnika wyświetl jego imię i liczbę punktów
            Text(text = "${player.name}: ${score} pkt")
        }

        Spacer(modifier = Modifier.height(16.dp)) // Odstęp między wynikami a przyciskiem

        // Przycisk powrotu do poprzedniego ekranu
        Button(
            onClick = onBack, // Wywołanie funkcji "onBack" po kliknięciu
            modifier = Modifier.fillMaxWidth() // Przycisk zajmuje pełną szerokość
        ) {
            Text("Powrót") // Tekst na przycisku
        }
    }
}
